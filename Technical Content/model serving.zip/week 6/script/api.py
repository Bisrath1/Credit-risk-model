from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import numpy as np
from sklearn.datasets import load_iris
iris = load_iris()
# Load the model
with open("iris_model.pkl", "rb") as f:
    model = pickle.load(f)

# Create FastAPI app
app = FastAPI()

# Input schema
class IrisInput(BaseModel):
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float

@app.post("/predict/")
async def predict(input_data: IrisInput):
    # Convert input data to a NumPy array
    data = np.array([[input_data.sepal_length, input_data.sepal_width, input_data.petal_length, input_data.petal_width]])
    # Make prediction
    prediction = model.predict(data)
    prediction_label = iris.target_names[prediction[0]]
    return {"prediction": prediction_label}
